/*
 * buzzer.h
 *
 *  Created on: Oct 6, 2022
 *      Author: mathi
 */

#ifndef BUZZER_INC_BUZZER_H_
#define BUZZER_INC_BUZZER_H_

#include "stm32l1xx_hal.h"
#include <string.h>

#define MUTE "-"
#define PWM_H 6399 // 200(µs) * 32(MHz) - 1

typedef struct{
	const char * name;
	double frequency;
	uint16_t ARR;
}TypeDef_Note;

void buzzer_play_note(TIM_HandleTypeDef * _htim, TypeDef_Note * _note);
void buzzer_mute(TIM_HandleTypeDef * _htim);
void buzzer_play_note_by_name(TIM_HandleTypeDef * _htim, TypeDef_Note * _notes , size_t _notes_sz, const char* _name);

#endif /* BUZZER_INC_BUZZER_H_ */
