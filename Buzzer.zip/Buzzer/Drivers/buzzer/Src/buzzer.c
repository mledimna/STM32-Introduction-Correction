/*
 * buzzer.c
 *
 *  Created on: Oct 6, 2022
 *      Author: mathi
 */

#include "buzzer.h"

void buzzer_play_note(TIM_HandleTypeDef * _htim, TypeDef_Note * _note){
	// Check timer handler & note parameter
	if ((_htim == NULL) || (_note == NULL)) return;

	// Set ARR to match expected note frequency
	_htim->Instance->ARR = _note->ARR;

	// Set CCR2 to match optimal high period for piezzo buzzer
	_htim->Instance->CCR2 = PWM_H;
}

void buzzer_mute(TIM_HandleTypeDef * _htim){
	// Check timer handler parameter
	if (_htim == NULL) return;

	// Set CCR2 to 0 (duty cycle at 0)
	_htim->Instance->CCR2 = 0;
}

void buzzer_play_note_by_name(TIM_HandleTypeDef * _htim, TypeDef_Note * _notes , size_t _notes_sz, const char* _name){
	// Check timer handler & note parameter
	if ((_htim == NULL) || (_notes == NULL) || (_name == NULL)) return;

	// Check if user ask for MUTE
	if (strcmp(MUTE, _name) == 0) buzzer_mute(_htim);

	// Check if user requested note is in note list
	for (int i=0; i<_notes_sz; i++) if (strcmp(_notes[i].name, _name) == 0) buzzer_play_note(_htim, &(_notes[i]));
}
