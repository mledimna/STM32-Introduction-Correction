/*
 * chenillard.c
 *
 *  Created on: Oct 9, 2022
 *      Author: mathi
 */


#include "chenillard.h"


void animer_chenillard(TypeDef_LED _leds[], size_t _leds_sz){
	// Used to store active LED
	static int led_index = 0;

	// Clear all LEDs
	for (int j=0; j<_leds_sz; j++) HAL_GPIO_WritePin(_leds[j].port, _leds[j].pin, GPIO_PIN_RESET);

	// Set desired LED
	HAL_GPIO_WritePin(_leds[led_index].port, _leds[led_index].pin, GPIO_PIN_SET);

	// Increment LED index
	++led_index;

	// Reset if needed
	if (led_index >= _leds_sz) led_index = 0;
}
