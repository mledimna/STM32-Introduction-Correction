/*
 * chenillard.h
 *
 *  Created on: Oct 9, 2022
 *      Author: mathi
 */

#ifndef CHENILLARD_CHENILLARD_H_
#define CHENILLARD_CHENILLARD_H_

#include "stm32l1xx_hal.h"

typedef struct{
	uint16_t pin;
	GPIO_TypeDef * port;
}TypeDef_LED;

void animer_chenillard(TypeDef_LED _leds[], size_t _leds_sz);

#endif /* CHENILLARD_CHENILLARD_H_ */
